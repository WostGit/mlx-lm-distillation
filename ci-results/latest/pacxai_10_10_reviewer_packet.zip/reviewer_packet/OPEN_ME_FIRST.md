# PACXAI Reviewer Packet

Start here:

1. Open `results/publishable_artifacts/index.html`.
2. Read `results/publishable_artifacts/REPORT.md`.
3. Inspect `lean-audit.log`.
4. Inspect `results/mlx_proof_matched/summary.json`.

Main result:

- Valid deterministic post-processing gap: 0.
- Candidate-best gap: 0.
- Finite code-cost gap: 0.
- Route-metadata false pass: true.
- Route-metadata lift: +7500 successes.

This is a finite recovery/privacy audit artifact, not a full Shannon/Gaussian/rate-distortion formalization.
